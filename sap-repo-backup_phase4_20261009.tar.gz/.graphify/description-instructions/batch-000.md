# Node Description Batch 1 of 2

Graphify is running in assistant/skill mode (no API key). You are the host
assistant (Claude Code / Codex / Gemini CLI). Read the prompt below and write
your JSON answer to the answer file.

## Prompt

You are documenting nodes in a knowledge graph.
For each entry below, write ONE concise factual plain-language sentence
describing what it is or does. Use only the provided context.
For a code symbol (kind=code-symbol — a function, class, or constant),
describe what the function/symbol does based on its name, source location
and neighbors — e.g. "Resolves the configured ontology profile from graphify.yaml.".
For an entity node (any other kind — e.g. a person, place, event, object),
describe what the entity is and its role, grounded in its type, its
relations (neighbors) and the provided citations/evidence — e.g.
"Lady Carfax, a wealthy heiress who disappears en route to Lausanne.".
Ground entity descriptions in the citations/evidence when present; do not
speculate beyond the context, so a node with no supporting context may be
left out of the reply.
Write every description in English (en). Do not switch languages.
No marketing language.
Respond ONLY with a JSON object mapping each node id (as a string) to its
one-sentence description — no prose, no markdown fences.

- "connection_base_sapconnectionprovider": "SapConnectionProvider" | kind=code-symbol | source=app/sap/connection/base.py:L7 | neighbors=[base.py, Abstract SAP connectivity boundary.    …, ABC, .call(), .ping(), ConnectionTestResult]
- "basemodel": "BaseModel" | kind=code-symbol | neighbors=[SapLocalSettings, RepositoryMetadata, RepositoryObject, RepositoryRelationships, RepositorySource, ObjectKey]
- "connection_btp_btpsapconnectionprovider": "BtpSapConnectionProvider" | kind=code-symbol | source=app/sap/connection/btp.py:L8 | neighbors=[btp.py, SapConnectionProvider, .call(), .__init__(), .ping(), Settings]
- "connection_local_localsapconnectionprovider": "LocalSapConnectionProvider" | kind=code-symbol | source=app/sap/connection/local.py:L8 | neighbors=[local.py, SapConnectionProvider, .call(), .__init__(), .ping(), Settings]
- "models_repository_repositoryobject": "RepositoryObject" | kind=code-symbol | source=app/models/repository.py:L43 | neighbors=[repository.py, BaseModel, ConnectionTestResult, ExportResult, HealthResult, SearchResult]
- "models_results_connectiontestresult": "ConnectionTestResult" | kind=code-symbol | source=app/models/results.py:L16 | neighbors=[Abstract SAP connectivity boundary.    …, SapConnectionProvider, BtpSapConnectionProvider, BTP connectivity provider placeholder. …, LocalSapConnectionProvider, Local RFC provider placeholder.      Ph…]
- "services_repository_repositoryservice": "RepositoryService" | kind=code-symbol | source=app/services/repository.py:L7 | neighbors=[repository.py, SapConnectionProvider, RepositoryObject, ObjectKey, RepositorySearchRequest, SearchResult]
- "core_config_settings": "Settings" | kind=code-symbol | source=app/core/config.py:L17 | neighbors=[BtpSapConnectionProvider, BTP connectivity provider placeholder. …, LocalSapConnectionProvider, Local RFC provider placeholder.      Ph…, config.py, get_settings()]
- "services_export_exportservice": "ExportService" | kind=code-symbol | source=app/services/export.py:L15 | neighbors=[export.py, Settings, RepositoryObject, ExportResult, .create_zip(), .__init__()]
- "models_requests_repositorysearchrequest": "RepositorySearchRequest" | kind=code-symbol | source=app/models/requests.py:L6 | neighbors=[requests.py, ExportRequest, BaseModel, .normalize_values(), Discover custom SAP repository objects.…, RepositoryService]
- "services_repository_rationale_12": "Discover custom SAP repository objects.          The SAP-side contract will ulti" | kind=entity | source=app/services/repository.py:L12 | neighbors=[SapConnectionProvider, RepositoryObject, ObjectKey, RepositorySearchRequest, SearchResult, .search()]
- "api_routes": "routes.py" | kind=code-symbol | source=app/api/routes.py:L1 | neighbors=[get_repository_object(), health(), repository_service(), sap_ping(), search_repository()]
- "models_repository": "repository.py" | kind=code-symbol | source=app/models/repository.py:L1 | neighbors=[RepositoryCategory, RepositoryMetadata, RepositoryObject, RepositoryRelationships, RepositorySource]
- "models_results_searchresult": "SearchResult" | kind=code-symbol | source=app/models/results.py:L23 | neighbors=[results.py, BaseModel, RepositoryObject, Discover custom SAP repository objects.…, RepositoryService]
- "connection_btp_rationale_9": "BTP connectivity provider placeholder.      Production implementation will resol" | kind=entity | source=app/sap/connection/btp.py:L9 | neighbors=[SapConnectionProvider, BtpSapConnectionProvider, Settings, ConnectionTestResult]
- "connection_local_rationale_9": "Local RFC provider placeholder.      Phase 2 will wire this to an RFC client aft" | kind=entity | source=app/sap/connection/local.py:L9 | neighbors=[SapConnectionProvider, LocalSapConnectionProvider, Settings, ConnectionTestResult]
- "models_requests_objectkey": "ObjectKey" | kind=code-symbol | source=app/models/requests.py:L22 | neighbors=[requests.py, BaseModel, Discover custom SAP repository objects.…, RepositoryService]
- "models_results": "results.py" | kind=code-symbol | source=app/models/results.py:L1 | neighbors=[ConnectionTestResult, ExportResult, HealthResult, SearchResult]
- "models_results_exportresult": "ExportResult" | kind=code-symbol | source=app/models/results.py:L28 | neighbors=[results.py, BaseModel, RepositoryObject, ExportService]
- "core_config": "config.py" | kind=code-symbol | source=app/core/config.py:L1 | neighbors=[get_settings(), SapLocalSettings, Settings]
- "models_requests": "requests.py" | kind=code-symbol | source=app/models/requests.py:L1 | neighbors=[ExportRequest, ObjectKey, RepositorySearchRequest]
- "models_results_healthresult": "HealthResult" | kind=code-symbol | source=app/models/results.py:L8 | neighbors=[results.py, BaseModel, RepositoryObject]
- "abc": "ABC" | kind=code-symbol | neighbors=[base.py, SapConnectionProvider]
- "app_main": "main.py" | kind=code-symbol | source=app/main.py:L1 | neighbors=[root(), test_health.py]
- "connection_base": "base.py" | kind=code-symbol | source=app/sap/connection/base.py:L1 | neighbors=[ABC, SapConnectionProvider]
- "connection_base_rationale_8": "Abstract SAP connectivity boundary.      Repository services depend on this cont" | kind=entity | source=app/sap/connection/base.py:L8 | neighbors=[SapConnectionProvider, ConnectionTestResult]
- "core_config_get_settings": "get_settings()" | kind=code-symbol | source=app/core/config.py:L41 | neighbors=[config.py, Settings]
- "core_config_saplocalsettings": "SapLocalSettings" | kind=code-symbol | source=app/core/config.py:L8 | neighbors=[config.py, BaseModel]
- "models_repository_repositorycategory": "RepositoryCategory" | kind=code-symbol | source=app/models/repository.py:L8 | neighbors=[repository.py, StrEnum]
- "models_repository_repositorymetadata": "RepositoryMetadata" | kind=code-symbol | source=app/models/repository.py:L18 | neighbors=[repository.py, BaseModel]
- "models_repository_repositoryrelationships": "RepositoryRelationships" | kind=code-symbol | source=app/models/repository.py:L35 | neighbors=[repository.py, BaseModel]
- "models_repository_repositorysource": "RepositorySource" | kind=code-symbol | source=app/models/repository.py:L29 | neighbors=[repository.py, BaseModel]
- "models_requests_exportrequest": "ExportRequest" | kind=code-symbol | source=app/models/requests.py:L27 | neighbors=[requests.py, RepositorySearchRequest]
- "sapconnectionprovider": "SapConnectionProvider" | kind=code-symbol | neighbors=[BtpSapConnectionProvider, LocalSapConnectionProvider]
- "services_export_exportservice_create_zip": ".create_zip()" | kind=code-symbol | source=app/services/export.py:L23 | neighbors=[ExportService, ._safe_name()]
- "services_export_exportservice_safe_name": "._safe_name()" | kind=code-symbol | source=app/services/export.py:L20 | neighbors=[ExportService, .create_zip()]
- "services_repository_repositoryservice_search": ".search()" | kind=code-symbol | source=app/services/repository.py:L11 | neighbors=[Discover custom SAP repository objects.…, RepositoryService]
- "tests_test_health": "test_health.py" | kind=code-symbol | source=tests/test_health.py:L1 | neighbors=[main.py, test_health_endpoint()]
- "api_routes_get_repository_object": "get_repository_object()" | kind=code-symbol | source=app/api/routes.py:L44 | neighbors=[routes.py]
- "api_routes_health": "health()" | kind=code-symbol | source=app/api/routes.py:L17 | neighbors=[routes.py]

## Instructions

Write a single JSON object mapping each node id to a one-sentence description
to: c:\sap-repository-intelligence\.graphify\description-instructions\batch-000.json

Keep each description factual and concise (one sentence). No markdown, no prose
outside the JSON object. It is acceptable to omit a node if context is
insufficient — but include every node you can ground confidently.

Example answer format:
```json
{
  "node_id_1": "Resolves the configured ontology profile from graphify.yaml.",
  "node_id_2": "Colonel James Barclay, an antagonist in The Crooked Man."
}
```
