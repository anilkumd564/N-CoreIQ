# Node Description Batch 2 of 2

Graphify is running in assistant/skill mode (no API key). You are the host
assistant (Claude Code / Codex / Gemini CLI). Read the prompt below and write
your JSON answer to the answer file.

## Prompt

You are documenting nodes in a knowledge graph.
For each entry below, write ONE concise factual plain-language sentence
describing what it is or does. Use only the provided context.
For a code symbol (kind=code-symbol — a function, class, or constant),
describe what the function/symbol does based on its name, source location
and neighbors — e.g. "Resolves the configured ontology profile from graphify.yaml.".
For an entity node (any other kind — e.g. a person, place, event, object),
describe what the entity is and its role, grounded in its type, its
relations (neighbors) and the provided citations/evidence — e.g.
"Lady Carfax, a wealthy heiress who disappears en route to Lausanne.".
Ground entity descriptions in the citations/evidence when present; do not
speculate beyond the context, so a node with no supporting context may be
left out of the reply.
Write every description in English (en). Do not switch languages.
No marketing language.
Respond ONLY with a JSON object mapping each node id (as a string) to its
one-sentence description — no prose, no markdown fences.

- "api_routes_repository_service": "repository_service()" | kind=code-symbol | source=app/api/routes.py:L12 | neighbors=[routes.py]
- "api_routes_sap_ping": "sap_ping()" | kind=code-symbol | source=app/api/routes.py:L27 | neighbors=[routes.py]
- "api_routes_search_repository": "search_repository()" | kind=code-symbol | source=app/api/routes.py:L33 | neighbors=[routes.py]
- "app_main_root": "root()" | kind=code-symbol | source=app/main.py:L17 | neighbors=[main.py]
- "basesettings": "BaseSettings" | kind=code-symbol | neighbors=[Settings]
- "connection_base_sapconnectionprovider_call": ".call()" | kind=code-symbol | source=app/sap/connection/base.py:L20 | neighbors=[SapConnectionProvider]
- "connection_base_sapconnectionprovider_ping": ".ping()" | kind=code-symbol | source=app/sap/connection/base.py:L16 | neighbors=[SapConnectionProvider]
- "connection_btp": "btp.py" | kind=code-symbol | source=app/sap/connection/btp.py:L1 | neighbors=[BtpSapConnectionProvider]
- "connection_btp_btpsapconnectionprovider_call": ".call()" | kind=code-symbol | source=app/sap/connection/btp.py:L28 | neighbors=[BtpSapConnectionProvider]
- "connection_btp_btpsapconnectionprovider_init": ".__init__()" | kind=code-symbol | source=app/sap/connection/btp.py:L15 | neighbors=[BtpSapConnectionProvider]
- "connection_btp_btpsapconnectionprovider_ping": ".ping()" | kind=code-symbol | source=app/sap/connection/btp.py:L18 | neighbors=[BtpSapConnectionProvider]
- "connection_factory": "factory.py" | kind=code-symbol | source=app/sap/connection/factory.py:L1 | neighbors=[build_sap_connection_provider()]
- "connection_factory_build_sap_connection_provider": "build_sap_connection_provider()" | kind=code-symbol | source=app/sap/connection/factory.py:L7 | neighbors=[factory.py]
- "connection_local": "local.py" | kind=code-symbol | source=app/sap/connection/local.py:L1 | neighbors=[LocalSapConnectionProvider]
- "connection_local_localsapconnectionprovider_call": ".call()" | kind=code-symbol | source=app/sap/connection/local.py:L39 | neighbors=[LocalSapConnectionProvider]
- "connection_local_localsapconnectionprovider_init": ".__init__()" | kind=code-symbol | source=app/sap/connection/local.py:L15 | neighbors=[LocalSapConnectionProvider]
- "connection_local_localsapconnectionprovider_ping": ".ping()" | kind=code-symbol | source=app/sap/connection/local.py:L18 | neighbors=[LocalSapConnectionProvider]
- "mcp_server": "server.py" | kind=code-symbol | source=app/mcp/server.py:L1 | neighbors=[MCP adapter boundary for SAP Repository…]
- "mcp_server_rationale_1": "MCP adapter boundary for SAP Repository Intelligence.  Version 0.1 intentionally" | kind=entity | source=app/mcp/server.py:L1 | neighbors=[server.py]
- "models_requests_repositorysearchrequest_normalize_values": ".normalize_values()" | kind=code-symbol | source=app/models/requests.py:L18 | neighbors=[RepositorySearchRequest]
- "services_export": "export.py" | kind=code-symbol | source=app/services/export.py:L1 | neighbors=[ExportService]
- "services_export_exportservice_init": ".__init__()" | kind=code-symbol | source=app/services/export.py:L16 | neighbors=[ExportService]
- "services_repository": "repository.py" | kind=code-symbol | source=app/services/repository.py:L1 | neighbors=[RepositoryService]
- "services_repository_repositoryservice_get_object": ".get_object()" | kind=code-symbol | source=app/services/repository.py:L28 | neighbors=[RepositoryService]
- "services_repository_repositoryservice_init": ".__init__()" | kind=code-symbol | source=app/services/repository.py:L8 | neighbors=[RepositoryService]
- "strenum": "StrEnum" | kind=code-symbol | neighbors=[RepositoryCategory]
- "tests_test_health_test_health_endpoint": "test_health_endpoint()" | kind=code-symbol | source=tests/test_health.py:L6 | neighbors=[test_health.py]
- "tests_test_search_request": "test_search_request.py" | kind=code-symbol | source=tests/test_search_request.py:L1 | neighbors=[test_search_request_normalizes_filters()]
- "tests_test_search_request_test_search_request_normalizes_filters": "test_search_request_normalizes_filters()" | kind=code-symbol | source=tests/test_search_request.py:L4 | neighbors=[test_search_request.py]
- "api_init": "__init__.py" | kind=code-symbol | source=app/api/__init__.py:L1
- "app_init": "__init__.py" | kind=code-symbol | source=app/__init__.py:L1
- "connection_init": "__init__.py" | kind=code-symbol | source=app/sap/connection/__init__.py:L1
- "core_init": "__init__.py" | kind=code-symbol | source=app/core/__init__.py:L1
- "export_init": "__init__.py" | kind=code-symbol | source=app/export/__init__.py:L1
- "mcp_init": "__init__.py" | kind=code-symbol | source=app/mcp/__init__.py:L1
- "models_init": "__init__.py" | kind=code-symbol | source=app/models/__init__.py:L1
- "sap_init": "__init__.py" | kind=code-symbol | source=app/sap/__init__.py:L1
- "services_init": "__init__.py" | kind=code-symbol | source=app/services/__init__.py:L1

## Instructions

Write a single JSON object mapping each node id to a one-sentence description
to: c:\sap-repository-intelligence\.graphify\description-instructions\batch-001.json

Keep each description factual and concise (one sentence). No markdown, no prose
outside the JSON object. It is acceptable to omit a node if context is
insufficient — but include every node you can ground confidently.

Example answer format:
```json
{
  "node_id_1": "Resolves the configured ontology profile from graphify.yaml.",
  "node_id_2": "Colonel James Barclay, an antagonist in The Crooked Man."
}
```
