# Community Labeling

Graphify is running in assistant/skill mode (no API key). You are the host
assistant (Claude Code / Codex / Gemini CLI). Read the community listing below
and write 2-5 word plain-language names for each.

## Language

Write every name in English (en). Do not switch languages.

## Communities

Community 0: RepositoryObject, ConnectionTestResult, BaseModel, repository.py, RepositoryCategory, RepositoryMetadata, RepositoryRelationships, RepositorySource, results.py, ExportResult, HealthResult, SearchResult
Community 1: SapConnectionProvider, LocalSapConnectionProvider, ABC, base.py, Abstract SAP connectivity boundary.      Repository services, .call(, .ping(, local.py, .__init__(, Local RFC provider placeholder.      Phase 2 will wire this 
Community 2: BtpSapConnectionProvider, Settings, BaseSettings, btp.py, .call(, .__init__(, .ping(, BTP connectivity provider placeholder.      Production imple, config.py, get_settings(, SapLocalSettings, SapConnectionProvider
Community 3: RepositorySearchRequest, Discover custom SAP repository objects.          The SAP-sid, RepositoryService, requests.py, ExportRequest, ObjectKey, .normalize_values(, repository.py, .get_object(, .__init__(, .search(
Community 4: routes.py, get_repository_object(, health(, repository_service(, sap_ping(, search_repository(
Community 5: ExportService, export.py, .create_zip(, .__init__(, ._safe_name(
Community 6: main.py, root(, test_health.py, test_health_endpoint(
Community 7: factory.py, build_sap_connection_provider(
Community 8: server.py, MCP adapter boundary for SAP Repository Intelligence.  Versi
Community 9: test_search_request.py, test_search_request_normalizes_filters(
Community 10: __init__.py
Community 11: __init__.py
Community 12: __init__.py
Community 13: __init__.py
Community 14: __init__.py
Community 15: __init__.py
Community 16: __init__.py
Community 17: __init__.py
Community 18: __init__.py

## Instructions

Write a single JSON object mapping each community id (as a string) to its
2-5 word name to: c:\sap-repository-intelligence\.graphify\label-instructions\communities.json

Example:
```json
{
  "0": "Authentication Flow",
  "1": "Authentication Flow",
  "2": "Authentication Flow"
}
```

Then re-run `graphify update` (or `graphify label`) to ingest the names.
