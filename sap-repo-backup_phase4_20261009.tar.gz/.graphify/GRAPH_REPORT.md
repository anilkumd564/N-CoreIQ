# Graph Report - .  (2026-10-09)

## Corpus Check
- Corpus is ~22,399 words - fits in a single context window. You may not need a graph.

## Summary
- 718 nodes · 2836 edges · 28 communities detected
- Extraction: 45% EXTRACTED · 55% INFERRED · 0% AMBIGUOUS · INFERRED: 1572 edges (avg confidence: 0.5)
- Token cost: 0 input · 0 output
- Edge kinds: uses: 1572 · calls: 474 · contains: 319 · rationale_for: 216 · method: 132 · MODIFIES: 69 · inherits: 40 · imports_from: 7 · ON_BRANCH: 4 · PARENT_OF: 3


## Input Scope
- Requested: auto
- Resolved: committed (source: default-auto)
- Included files: 43 · Candidates: 55
- Excluded: 23 untracked · 7800 ignored · 0 sensitive · 0 missing committed
- Recommendation: Use --scope all or graphify.yaml inputs.corpus for a knowledge-base folder.

## Graph Freshness
- Built from Git commit: `ec717aa`
- Compare this hash to `git rev-parse HEAD` before trusting freshness-sensitive graph output.
## God Nodes (most connected - your core abstractions)
1. `SapConnectionProvider` - 103 edges
2. `SAPFunctionExecutionError` - 97 edges
3. `Settings` - 96 edges
4. `RepositorySearchRequest` - 91 edges
5. `SAPCommunicationError` - 88 edges
6. `ConnectionTestResult` - 77 edges
7. `PackageResolutionResult` - 75 edges
8. `SAPConfigurationError` - 71 edges
9. `SAPAuthenticationError` - 69 edges
10. `ODataSAPConnectionProvider` - 67 edges

## Surprising Connections (you probably didn't know these)
- `Phase 3 — Request validation tests.  Covers all RepositorySearchRequest valida` --uses--> `RepositorySearchRequest`  [INFERRED]
  tests/test_phase3_validation.py → app/models/requests.py
- `All-blank package list → empty after normalisation → safety rule fires.` --uses--> `RepositorySearchRequest`  [INFERRED]
  tests/test_phase3_validation.py → app/models/requests.py
- `Empty object_types is valid – the service will use all Phase 3 types.` --uses--> `RepositorySearchRequest`  [INFERRED]
  tests/test_phase3_validation.py → app/models/requests.py
- `No packages, no patterns, no all_custom_objects → 422-equivalent ValueError.` --uses--> `RepositorySearchRequest`  [INFERRED]
  tests/test_phase3_validation.py → app/models/requests.py
- `Explicit all_custom_objects=false with no other selectors is rejected.` --uses--> `RepositorySearchRequest`  [INFERRED]
  tests/test_phase3_validation.py → app/models/requests.py

## Communities

### Community 0 - "Community 0"
Cohesion: 0.06
Nodes (102): FastAPI route definitions for N-CoreIQ.  Implements:   GET  /api/v1/health, BaseModel, ODataDiscoveryResult, Result of a single RepositoryObjectsSet OData call.      The ``rows`` list conta, MatchReason, PackageInfo, PackageResolutionResult, A single SAP development package returned by PackagesSet (OData).      Maps the (+94 more)

### Community 1 - "Community 1"
Cohesion: 0.07
Nodes (74): _make_http_response(), _mock_svc_result(), _odata_settings(), _patch_http(), _patch_http_raise(), _patch_svc(), _payload(), _row() (+66 more)

### Community 2 - "Community 2"
Cohesion: 0.17
Nodes (43): ODataSAPConnectionProvider, SAP Gateway OData V2 connection provider.  Uses httpx over HTTPS to communicat, Return the fully-qualified OData service root URL without trailing slash., Return the httpx TLS verification setting., Build an httpx.AsyncClient with auth, TLS, and timeout configured., Map an httpx network-level exception to a controlled domain error., Escape a string for use inside an OData V2 string literal.          OData V2 s, Reliably convert an OData V2 value to a Python bool.          OData V2 over JS (+35 more)

### Community 3 - "Community 3"
Cohesion: 0.11
Nodes (9): _clas_row(), _discover_response(), _make_service(), _make_service_multi(), _make_service_rfc(), _odata_result(), _prog_row(), TestPackageResolution (+1 more)

### Community 4 - "Community 4"
Cohesion: 0.09
Nodes (41): _make_response(), _odata_settings(), _patch_http(), _patch_http_raise(), test_factory_invalid_mode_raises_configuration_error(), test_factory_mode_odata_returns_odata_provider(), test_odata_normalized_response_matches_spec(), test_odata_ping_connect_error_raises_connection_error() (+33 more)

### Community 5 - "Community 5"
Cohesion: 0.14
Nodes (33): Local SAP RFC connection provider.  Uses PyRFC + the SAP NetWeaver RFC SDK to co, Primary Phase 2 connectivity check using Z_MCP_REPO_PING., Execute an RFC function module and return its raw result dict.          The allo, Local RFC provider for direct SAP ECC Development connectivity., Open an RFC connection only for the duration of the call.          Never connect, SapLocalSettings, Exception, Domain exceptions for SAP connectivity (Phase 2) and repository operations (Phas (+25 more)

### Community 6 - "Community 6"
Cohesion: 0.05
Nodes (9): Phase 3 — Request validation tests.  Covers all RepositorySearchRequest valida, All-blank package list → empty after normalisation → safety rule fires., Empty object_types is valid – the service will use all Phase 3 types., No packages, no patterns, no all_custom_objects → 422-equivalent ValueError., Explicit all_custom_objects=false with no other selectors is rejected., test_all_blank_packages_treated_as_empty(), test_all_fields_empty_and_all_custom_objects_false_rejected(), test_empty_object_types_accepted() (+1 more)

### Community 7 - "Community 7"
Cohesion: 0.12
Nodes (20): BaseSettings, BtpSapConnectionProvider, build_sap_connection_provider(), SAP connection provider factory.  Selects the appropriate SapConnectionProvider, Return the provider for the configured SAP_CONNECTION_MODE.      Raises:, LocalSapConnectionProvider, Local RFC provider placeholder.      Phase 2 will wire this to an RFC client aft, OData Gateway connection settings for SAP ECC connectivity.      Environment var (+12 more)

### Community 8 - "Community 8"
Cohesion: 0.15
Nodes (24): Discover SAP repository objects via RepositoryObjectsSet (OData).          Each, Abstract SAP connectivity boundary.      Repository services depend on this cont, Invoke an RFC function module.          Implementations must call ensure_allowed, Invoke an RFC function module.          Implementations must call ensure_allowed, Backward-compatible entry point enforcing the RFC allow-list., Backward-compatible entry point enforcing the RFC allow-list., Resolve an SAP package hierarchy via PackagesSet (OData).          Default imple, Abstract SAP connectivity boundary.      Repository services depend on this cont (+16 more)

### Community 9 - "Community 9"
Cohesion: 0.13
Nodes (11): _make_prog_object(), _make_response(), test_all_custom_objects_true_accepted(), test_match_reason_both_in_response(), test_match_reason_name_pattern_in_response(), test_sap_ping_endpoint_still_exists(), test_search_200_truncated_result(), test_search_200_zero_results() (+3 more)

### Community 10 - "Community 10"
Cohesion: 0.16
Nodes (13): _patch_runtime_available(), _settings(), test_authentication_failure_is_mapped_to_sap_authentication_error(), test_call_allowed_function_rejects_unapproved_name_before_sap_call(), test_communication_failure_is_mapped_to_controlled_error(), test_factory_handles_btp_mode_without_silent_fallback(), test_factory_selects_local_provider_by_default(), test_failed_mocked_z_mcp_repo_ping_raises_function_execution_error() (+5 more)

### Community 11 - "Community 11"
Cohesion: 0.10
Nodes (20): Foundation tests for Phase 1 (Version 0.1) stability.  These tests validate th, 8. Phase 3 repository search responds with a controlled status code.      Phas, 1. Health endpoint returns HTTP 200., 2. Health response contains expected application fields., 3. Application loads with a recognized connection mode (local or odata)., 4. Repository search request model accepts valid input., 4. Repository search request model accepts valid input., 5. Repository search request rejects structurally invalid input. (+12 more)

### Community 12 - "Community 12"
Cohesion: 0.12
Nodes (2): 239bddf Phase 1 (v0.1): SAP Repository Intelligence Layer foundation - validated", MCP adapter boundary for SAP Repository Intelligence.  Version 0.1 intentionally

### Community 13 - "Community 13"
Cohesion: 0.14
Nodes (6): ABC, ec717aa feat(phase3): integrate RepositoryObjectsSet - repository discovery complete, Analyze the extracted SAP certificate to determine if it can serve as a CA bundl, Extract cert info and AIA from SAP Gateway leaf certificate., Debug TLS connection to SAP with detailed error reporting., TLS diagnostics for SAP Gateway certificate chain.

### Community 14 - "Community 14"
Cohesion: 0.23
Nodes (7): main, 72b92cb Phase 2: Add SAP RFC runtime, allowlist, exceptions, and connectivity tests, 974b109 Phase3-Phase4-preflight-smoke-test-117-passing-Phase4-stub-RFCs-reserved, get_settings(), ensure_allowed(), Explicit RFC allow-list for Phase 2.  Only function modules listed here may be, Raise SAPRFCNotAllowedError if function_name is not on the allow-list.

### Community 15 - "Community 15"
Cohesion: 0.18
Nodes (10): Phase 3 SAP repository object models.  Defines the canonical RepositoryObject re, High-level grouping used for classification in future phases., Placeholder for Phase 4 metadata enrichment., Placeholder for Phase 4 source extraction., Placeholder for Phase 8 dependency analysis., RepositoryCategory, RepositoryMetadata, RepositoryRelationships (+2 more)

### Community 16 - "Community 16"
Cohesion: 0.32
Nodes (7): _attempt_import(), get_pyrfc_module(), get_rfc_runtime_status(), Defensive loader for the Python RFC adapter (PyRFC).  PyRFC requires the propr, Attempt to import pyrfc exactly once, capturing any failure safely., Return whether the RFC runtime is available, without raising., Return the imported pyrfc module, or None if unavailable.      Callers must ch

### Community 18 - "Community 18"
Cohesion: 0.33
Nodes (2): _MockAsyncClient, Minimal async context manager wrapping a list of prepared responses.

### Community 19 - "Community 19"
Cohesion: 0.33
Nodes (2): _RaisingMockClient, Async context manager that raises a RequestError on get().

### Community 20 - "Community 20"
Cohesion: 0.50
Nodes (1): ExportService

### Community 21 - "Community 21"
Cohesion: 0.40
Nodes (1): _MockAsyncClient

### Community 22 - "Community 22"
Cohesion: 0.40
Nodes (1): _RaisingMockClient

### Community 23 - "Community 23"
Cohesion: 0.50
Nodes (3): get_friendly_type(), Phase 3 SAP repository object-type definitions.  Contains the Phase 3 approved, Return the friendly display name for a SAP native object type.      Falls back

### Community 24 - "Community 24"
Cohesion: 0.50
Nodes (3): ExportRequest, Phase 3 repository search request models.  Defines the canonical RepositorySearc, Bulk export request – extends the search request with export options.

### Community 25 - "Community 25"
Cohesion: 0.50
Nodes (4): 7. Application startup does not require an available ECC system., 7. Application startup does not require an available ECC system., 7. Application startup does not require an available ECC system., test_application_startup_does_not_require_ecc_system()

### Community 26 - "Community 26"
Cohesion: 0.67
Nodes (2): Serialize settings with the SAP passwords always redacted.          The in-memor, Serialize settings with the SAP password always redacted.          The in-memory

### Community 27 - "Community 27"
Cohesion: 0.67
Nodes (2): Return a configuration dict with the password redacted.          Used anywhere S, Return a configuration dict with the password redacted.          Used anywhere S

### Community 28 - "Community 28"
Cohesion: 1.00
Nodes (1): Return a configuration dict with the password always redacted.

## Knowledge Gaps
- **49 isolated node(s):** `OData Gateway connection settings for SAP ECC connectivity.      Environment var`, `Return a configuration dict with the password always redacted.`, `Return a configuration dict with the password redacted.          Used anywhere S`, `Serialize settings with the SAP passwords always redacted.          The in-memor`, `MCP adapter boundary for SAP Repository Intelligence.  Version 0.1 intentionally` (+44 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **Thin community `Community 12`** (2 nodes): `239bddf Phase 1 (v0.1): SAP Repository Intelligence Layer foundation - validated"`, `MCP adapter boundary for SAP Repository Intelligence.  Version 0.1 intentionally`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 18`** (2 nodes): `_MockAsyncClient`, `Minimal async context manager wrapping a list of prepared responses.`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 19`** (2 nodes): `_RaisingMockClient`, `Async context manager that raises a RequestError on get().`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 20`** (1 nodes): `ExportService`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 21`** (1 nodes): `_MockAsyncClient`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 22`** (1 nodes): `_RaisingMockClient`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 26`** (2 nodes): `Serialize settings with the SAP passwords always redacted.          The in-memor`, `Serialize settings with the SAP password always redacted.          The in-memory`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 27`** (2 nodes): `Return a configuration dict with the password redacted.          Used anywhere S`, `Return a configuration dict with the password redacted.          Used anywhere S`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 28`** (1 nodes): `Return a configuration dict with the password always redacted.`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `RepositorySearchRequest` connect `Community 0` to `Community 24`, `Community 11`, `Community 25`, `Community 3`, `Community 6`?**
  _High betweenness centrality (0.108) - this node is a cross-community bridge._
- **Why does `SAPFunctionExecutionError` connect `Community 5` to `Community 0`, `Community 7`, `Community 2`, `Community 18`, `Community 19`, `Community 8`, `Community 3`, `Community 21`, `Community 22`?**
  _High betweenness centrality (0.093) - this node is a cross-community bridge._
- **Why does `Settings` connect `Community 7` to `Community 0`, `Community 8`, `Community 5`, `Community 2`, `Community 14`, `Community 26`, `Community 20`, `Community 11`, `Community 25`, `Community 18`, `Community 19`, `Community 21`, `Community 22`?**
  _High betweenness centrality (0.093) - this node is a cross-community bridge._
- **Are the 92 inferred relationships involving `SapConnectionProvider` (e.g. with `PackageResolutionResult` and `ConnectionTestResult`) actually correct?**
  _`SapConnectionProvider` has 92 INFERRED edges - model-reasoned connections that need verification._
- **Are the 94 inferred relationships involving `SAPFunctionExecutionError` (e.g. with `FastAPI route definitions for N-CoreIQ.  Implements:   GET  /api/v1/health` and `LocalSapConnectionProvider`) actually correct?**
  _`SAPFunctionExecutionError` has 94 INFERRED edges - model-reasoned connections that need verification._
- **Are the 92 inferred relationships involving `Settings` (e.g. with `FastAPI route definitions for N-CoreIQ.  Implements:   GET  /api/v1/health` and `BtpSapConnectionProvider`) actually correct?**
  _`Settings` has 92 INFERRED edges - model-reasoned connections that need verification._
- **Are the 82 inferred relationships involving `RepositorySearchRequest` (e.g. with `FastAPI route definitions for N-CoreIQ.  Implements:   GET  /api/v1/health` and `_DiscoveryPlan`) actually correct?**
  _`RepositorySearchRequest` has 82 INFERRED edges - model-reasoned connections that need verification._